@extends('dashboard')

@section('joke')
    <h1 class="text-base font-semibold leading-7 text-indigo-800">Chuck Norris Joke:</h1>
    <h2 class="text-base font-semibold leading-7 text-indigo-600">{{ $joke }}</h2>
@endsection
